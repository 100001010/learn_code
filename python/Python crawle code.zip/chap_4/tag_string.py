#encoding:UTF-8
import requests

from bs4 import BeautifulSoup

soup = BeautifulSoup("<h2 id='message'>Hello, Tutorialspoint!</h2>", 'html.parser')

tag = soup.h2
print(tag)
print(tag.string)
print(type(tag.string))