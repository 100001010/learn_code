# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 13:58:24 2020

@author: wuhsiao
"""


import requests
from bs4 import BeautifulSoup

url = "http://www.twnic.org.tw"
my_headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'}
response = requests.get(url, headers = my_headers)
response.encoding = "utf-8"

root = BeautifulSoup(response.text, "html.parser")

div = root.find_all("div",class_="row")

for anydiv in div:
    subdiv = anydiv.find_all("div",{"class":"title"})
    for anyanswer in subdiv:
       if anyanswer.string != None:
            print(anyanswer.string)