# -*- coding: utf-8 -*-
"""
Created on Thu Aug 13 13:58:24 2020

@author: wuhsiao
"""

import requests
from bs4 import BeautifulSoup

def get_url(url,my_headers):
    response = requests.get(url, headers = my_headers)
    response.encoding="utf-8" 
            
    return response

def save_file(soup):
   string= soup.prettify()
   string.encode("utf-8")
   f = open("demo.txt", "a",encoding="utf-8") # a means Append - will append to the end of the file
   f.write(string)
   f.close() 
   


url = "https://www.doterra.com/TW/zh_TW/pl/single-oils"
my_headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0"}
data = get_url(url,my_headers)

root = BeautifulSoup(data.text,"html.parser")
save_file(root)

div = root.find_all("div", class_="col-xs-12 col-sm-4 col-lg-3")
answer = []
for anydiv in div:
    title=anydiv.find("a",{"href": True, "class":"title"})
    if title.string != None:
        answer.append(title.string)
                
print(answer)


     





