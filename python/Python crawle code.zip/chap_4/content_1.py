import requests
from bs4 import BeautifulSoup

html_doc = """
<div class="menu-hide">
	  <div class="menu-hide-inner">
		<form class="search mobile">
			<input type="text">
			<button type="submit"><i class="fa fa-search"></i></button>
		</form>	
		<ul class="submenu mobile">
			<li class="readmore blue"><a href="about.php">關於我們</a></li>
			<li class="readmore blue"><a href="https://blog.twnic.tw/news/">最新消息</a></li>
			<li class="readmore blue"><a href="download.php">下載專區</a></li>
			
		</ul>
		<ul class="menu mobile">
			<li><a href="dnservice.php">域名服務</a></li>
			<li><a href="ipasn.php">IP/ASN申請</a></li>
			<li><a href="webstatistic.php">網路統計</a></li>
			<li><a href="seminar.php">研討會</a></li>
			<li><a href="educate.php">教育訓練</a></li>
			<li><a href="responsibility.php">社會責任</a></li>
			<li><a href="whois_n.php">whois</a></li>
			<li><a href="https://blog.twnic.tw">Blog</a></li>
			<li><a href="https://blog.twnic.tw/videosyt/">影音專區</a></li>
		</ul>
	  </div>
</div>
"""
soup = BeautifulSoup(html_doc, 'html.parser')

temp = soup.find_all("li", {"class":"readmore blue"})
for anyli in temp:
    print(anyli.string)
