#encoding:UTF-8
import requests

#r = requests.get('https://en.wikipedia.org/')

from bs4 import BeautifulSoup

css_soup = BeautifulSoup('<p class="body"></p>', 'html.parser')
print(css_soup.p['class'])


css_soup = BeautifulSoup('<p class="body strikeout"></p>', 'html.parser')
print(css_soup.p['class']) # The answer is a list
print(css_soup.p.get('class'))
for i in css_soup.p['class']:
    print(i)
