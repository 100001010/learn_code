#encoding:UTF-8

import requests
from bs4 import BeautifulSoup

response = requests.get('https://en.wikipedia.org/')
soup = BeautifulSoup(response.text, 'html.parser')

print(soup.title)
print(soup.h1)
print(soup.html.h1)
print(soup.body.h1)
print(soup.html.body.h1)


