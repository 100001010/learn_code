# -*- coding: utf-8 -*-
"""
Created on Sun Aug 16 13:47:10 2020

@author: wuhsiao
"""
import requests
from bs4 import BeautifulSoup


def get_url(url,my_headers):
    response = requests.get(url, headers = my_headers)
    response.encoding="utf-8" 
            
    return response

url = "https://www.doterra.com/TW/zh_TW/pl/single-oils"
my_headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'}
data = get_url(url,my_headers)

root = BeautifulSoup(data.text,"html.parser")

titles = root.find_all("div", class_="grid-item grid-product")

for anytitle in titles:
    ref = anytitle.find_all('a',href=True)   
    for anyref in ref:
      # anyref['class'] = ['title'],anyref['class'][0] = title  
      if anyref['class'][0] == 'title':
         print(anyref.string)
         data = get_url("https://www.doterra.com"+anyref['href'],my_headers)
         root = BeautifulSoup(data.text,"html.parser")
             
         answer=root.find("div",id='prod-title').find_all('div')
         
         spec = [i.string for i in answer if i.string != None and i.string != '\n'] # 最後一筆資料為 '\n'
         print(spec)

