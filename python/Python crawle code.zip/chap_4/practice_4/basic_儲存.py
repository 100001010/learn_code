# -*- coding: utf-8 -*-
"""
Created on Sun Aug 16 13:47:10 2020

@author: wuhsiao
"""
import requests
from bs4 import BeautifulSoup
import pandas as pd

def get_url(url,my_headers):
    response = requests.get(url, headers = my_headers)
    response.encoding="utf-8" 
            
    return response

def save_file(soup):
   string= soup.prettify()
   string.encode("utf-8")
   f = open("demo.txt", "a",encoding="utf-8")
   f.write(string)
   f.close() 
   

url = "https://www.doterra.com/TW/zh_TW/pl/single-oils"
my_headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0'}
data = get_url(url,my_headers)

root = BeautifulSoup(data.text,"html.parser")
save_file(root)


titles = root.find_all("div", class_="grid-item grid-product")
df = pd.DataFrame(columns=['精油名稱','產品編號','規格(毫升)','建議售價','會員價','點數'])

for index, anytitle in enumerate(titles,1):
    ref = anytitle.find_all('a',href=True)     
    for anyref in ref:      
      # anyref['class'] = ['title'],anyref['class'][0] = title  
      if anyref['class'][0] == 'title':         
         data = get_url("https://www.doterra.com"+anyref['href'],my_headers)
         root = BeautifulSoup(data.text,"html.parser")
             
         answer=root.find("div",id='prod-title').find_all('div')
         final_data = [anyref.string]
        
#[<div>產品編號: 30430302</div>, <div>規格: 15 毫升</div>, <div>建議售價: NT $2,135</div>, 
#<div>會員價: NT $1,600</div>, <div>點數: 49</div>
# 我們只需要前五項

         for i in range(5): # 只要前 5 個即可
             number = []
                         
             temp = str(answer[i].string)
             
             for j in range(len(temp)):
# we only need the number and english character
               if 'a' <= temp[j] <= "z" or 'A' <= temp[j] <='Z' or '0' <= temp[j] <='9':
                   number += temp[j]                   
             number = "".join(number)  # return a string           
             final_data.append(number)
         
         df.loc[index] = final_data

df.to_csv('product_price_1.csv',encoding="utf_8_sig", index =False)
df.to_excel("product_price_1.xlsx", sheet_name="price", index=False)



