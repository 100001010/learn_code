
import pandas as pd
df = pd.DataFrame(columns=["第一行","第二行","第三行"])
df.loc[0] = [1,3,5]
df.loc[1] = [2,4,6]

df.to_csv('example.csv',encoding="utf_8_sig")
df.to_excel("example.xlsx", sheet_name="my_first")