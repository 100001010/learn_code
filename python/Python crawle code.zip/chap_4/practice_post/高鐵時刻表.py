# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 20:19:14 2021

@author: mcu
"""

# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import json
import pandas as pd

payload= {
	"SearchType": "S",
	"Lang": "TW",
	"StartStation": "TaoYuan",
	"EndStation": "ZuoYing",
	"OutWardSearchDate": "2023/11/21",
	"OutWardSearchTime": "06:00",
	"ReturnSearchDate": "2023/11/10",
	"ReturnSearchTime": "11:00",
	"DiscountType": ""
}

response = requests.post("https://www.thsrc.com.tw/TimeTable/Search", data = payload)
#print(response.text)
response.encoding="utf-8"

result = json.loads(response.text)

answer = [[i['TrainNumber'],i['DepartureTime'],i['DestinationTime']] for i in result['data']['DepartureTable']['TrainItem'] ]
print(answer)
df = pd.DataFrame(answer, columns=['班次','起始時間','到達時間'])
df.to_csv('schedule.csv',encoding="utf_8_sig")
df.to_excel("schedule.xlsx", sheet_name="schedule", index=False)