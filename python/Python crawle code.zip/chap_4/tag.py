#encoding:UTF-8
import requests
from bs4 import BeautifulSoup

soup = BeautifulSoup("<div class='tutorialsP'></div>", 'html.parser')

tag = soup.div
print(tag)
print(tag['class'])
print(type(tag['class']))