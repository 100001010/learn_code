# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 15:24:54 2020

@author: wuhsiao
"""

import requests 
import re
from bs4 import BeautifulSoup


url = "https://jimmy15923.github.io/518"
response = requests.get(url)
homepage = BeautifulSoup(response.text, "lxml")

result = [tag.string for tag in homepage.find_all("li", {"class":"comp_tel"})]

#The join() method takes all items in an iterable and joins them into one string.

result = " ".join(result)

print(result)

phone_number = re.findall("0[1-9]+-[0-9]+", result)

print(phone_number)



