# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 14:33:39 2021

@author: wuhsiao
"""

from bs4 import BeautifulSoup
import re

with open('example_page.html', 'r',encoding="utf-8") as f:

    contents = f.read()

    soup = BeautifulSoup(contents, 'html.parser')

    answer= soup.find_all(True,{"class":re.compile("z+")})
    print(answer)
    print()
    
    answer_1=soup.find_all(True,text=re.compile("python"))
    print(answer_1)
    print()
    for any in answer_1:
      print(any.string)

   