# -*- coding: utf-8 -*-
"""
Created on Wed Sep 23 15:24:54 2020

@author: wuhsiao
"""

import requests 
import re
from bs4 import BeautifulSoup


url = "https://jimmy15923.github.io/518"
response = requests.get(url)
homepage = BeautifulSoup(response.text, "html.parser")

#all_li = homepage.find_all("li",{"class":"comp_loca"},string=re.compile("新北"))
all_li = homepage.find_all("li",{"class":re.compile("comp_loca")})

print(all_li)
print()
#answer = [tag.string for tag in all_li]
answer = [tag.string for tag in all_li if "新北" in tag.string ]

print(answer)









