# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 14:33:39 2021

@author: wuhsiao
"""

from bs4 import BeautifulSoup
import re
import requests

response = requests.get("https://www.mcu.edu.tw")

soup = BeautifulSoup(response.text, 'html.parser')

answer= (soup.find_all(True, text =re.compile("銘傳大學")))
print(answer)

for anyanswer in answer:
    print(anyanswer.string)
    
    
   