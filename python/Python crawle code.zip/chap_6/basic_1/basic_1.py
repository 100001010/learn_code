# -*- coding: utf-8 -*-
"""
Created on Mon Apr 12 14:33:39 2021

@author: wuhsiao
"""

from bs4 import BeautifulSoup
import re

with open('example_page.html', 'r',encoding="utf-8") as f:

    contents = f.read()

    soup = BeautifulSoup(contents, 'html.parser')

    answer= (soup.find_all(True, {"href":re.compile(
                                      "http://foundation.datasci.tw")}))
    print(answer)
    
    
   