# -*- coding: utf-8 -*-
"""
Created on Tue Mar 30 20:19:14 2021

@author: mcu
"""

# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np

payload = {
	"_csrf": "ab13ea71-0ca4-4e82-a480-235c31444f72",
	"startStation": "1080-桃園",
	"endStation": "4400-高雄",
	"transfer": "ONE",
	"rideDate": "2023/11/30",
	"startOrEndTime": "true",
	"startTime": "00:00",
	"endTime": "23:59",
	"trainTypeList": "ALL",
	"queryClassification": "NORMAL",
	"query": "查詢"
}

my_headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0'}
response = requests.post("https://tip.railway.gov.tw/tra-tip-web/tip/tip001/tip112/querybytime", data = payload,headers = my_headers)
response.encoding="utf-8"


soup = BeautifulSoup(response.text,"html.parser")

df = pd.DataFrame(columns=["始發站 → 終點站","出發時間","到達時間","行駛時間"])

tr = soup.find_all("tr",class_="trip-column")


for i, anytr in enumerate(tr):
    td = anytr.find_all("td")
    span = td[0].find_all("span",class_="location")
    for index, anyspan in enumerate(span):
         if index:
            end = anyspan.string
         else:
            start = anyspan.string
    start_end = start+' --> '+ end
       
    departure_time = td[1].string
    arrived_time = td[2].string
    travel_time = td[3].string
    df.loc[i] = [start_end,departure_time,arrived_time,travel_time]
      
df.to_csv('Taiwan_schedule.csv',encoding="utf_8_sig")
df.to_excel("Taiwan_schedule.xlsx", sheet_name="Taiwan_schedule", index=False)
