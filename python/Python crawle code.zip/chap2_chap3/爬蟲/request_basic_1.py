# -*- coding: utf-8 -*-
"""
Created on Sun Apr 11 18:19:23 2021

@author: mcu
"""


# -*- coding: utf-8 -*-
import requests
from bs4 import BeautifulSoup

# use get method to request  
response = requests.get('https://www.mcu.edu.tw')

# change encoding to uft-8
response.encoding = 'utf-8'
print(f'回應的 html 是: \n {response.text}')
print(f'status code 是: {response.status_code}')
