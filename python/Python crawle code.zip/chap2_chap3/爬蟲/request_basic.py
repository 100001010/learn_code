#encoding:UTF-8
import requests

r = requests.get('https://en.wikipedia.org/')


print(type(r))
print(len(r.text))
print(r.status_code)
