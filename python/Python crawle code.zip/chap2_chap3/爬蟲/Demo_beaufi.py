#encoding:UTF-8
import requests

r = requests.get('https://www.mcu.edu.tw/')

from bs4 import BeautifulSoup

soup = BeautifulSoup(r.text, 'html.parser')

print(soup.title)