# -*- coding: utf-8 -*-
"""
Created on Sun Apr 11 18:27:39 2021

@author: mcu
"""


import requests
from bs4 import BeautifulSoup

payload = {
"CinemaCode":"TP",
}




#https://www.vscinemas.com.tw/ShowTimes//ShowTimes/
response = requests.post("https://www.vscinemas.com.tw/ShowTimes//ShowTimes/GetShowTimes", 
                         data = payload)
print(response.text)

