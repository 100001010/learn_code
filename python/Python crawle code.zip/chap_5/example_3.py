# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 21:12:03 2021

@author: wuhsiao
"""
import re

abc = "transbiz.com.tw/fb/post01. transbiz.com.tw/fb/post02,transbiz.com.tw/fb/post03,transbiz.com.tw/web/post01,transbiz.com.tw/web/post02,transbiz.com.tw/web/post03"
answers = re.findall(r'[a-z.]+/[a-z]+/post0[1-3]+', abc)

for anyans in answers:
    print(anyans)
    
