# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 21:12:03 2021

@author: wuhsiao
"""
import re

abc = 'guru99@google.com, careerguru99@hotmail.com, users@yahoomail.com'
emails = re.findall(r'[a-z1-9\.-]+@[a-z\.-]+', abc)
#emails=re.findall(r'[\w\.-]+@[\w\.-]+', abc)
for email in emails:
    print(email)