# -*- coding: utf-8 -*-
"""
Created on Wed Apr 28 17:32:47 2021

@author: wuhsiao
"""


import re
string='臺中市南屯區埔興段35-12地號'
pattern = '(\d+-*\d*)'


match= re.findall(pattern, string)

print(match)